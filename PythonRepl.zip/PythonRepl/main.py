import discord
from discord.ext import commands, tasks
from flask import Flask
from threading import Thread
import os

# ------------------ DISCORD BOT SETUP ------------------ #
intents = discord.Intents.default()
intents.presences = True  # so we can detect online/offline
intents.members = True

bot = commands.Bot(command_prefix="!", intents=intents)

# Replace with IDs of OGs/admins you want to track
TRACKED_USER_IDS = [
    322390504169799681,
    495601596991012885,
    1338922461848277052,
    1356647389359767635,
    886439184838049895,
    1417781734405312575,
    1376974996588597288,
    1020948225726885908,
    1380175336410710077,
    1232936641413382187,
    1265634841479614489
]
ANNOUNCE_CHANNEL_ID = 1369091668724154419  # where to send announcements

@bot.event
async def on_ready():
    print(f"Logged in as {bot.user}")

@bot.event
async def on_presence_update(before, after):
    if after.id in TRACKED_USER_IDS:
        if str(before.status) != "online" and str(after.status) == "online":
            channel = bot.get_channel(ANNOUNCE_CHANNEL_ID)
            if channel:
                await channel.send(f"🔥 **{after.display_name}** just came online!")

# ------------------ TINY WEB SERVER ------------------ #
app = Flask('')

@app.route('/')
def home():
    return "I'm alive!"

def run():
    app.run(host='0.0.0.0', port=5000)

def keep_alive():
    t = Thread(target=run)
    t.start()

keep_alive()

# ------------------ RUN THE BOT ------------------ #
bot.run(os.getenv("DISCORD_BOT_TOKEN"))
